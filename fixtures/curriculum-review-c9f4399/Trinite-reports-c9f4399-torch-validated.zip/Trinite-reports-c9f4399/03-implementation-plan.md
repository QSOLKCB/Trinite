# Implementation plan

This is advice for a subsequent implementation and experiment. The proposed refinement has not been implemented or trained. The follow-up validation exercises bounded model/training fixtures, reported in `04-full-validation.md`; the original checkout remains unchanged.

## First step: measure the existing task-balanced recipe

The repository already provides a source-bound, training-only control/candidate comparison with full optimizer replay and retained failures. It keeps the dense 86,528-parameter model, context 64, four arithmetic/four maths visits per update, 8,192 updates, seeds 0/1 and final-checkpoint selection. The candidate balances maths tasks. Running that declared experiment is the smallest useful next step before adding a new curriculum mechanism.

Use a compatible interpreter and the hash-locked CPU environment from the separate checkout's `docs/GETTING_STARTED.md`. Publish the numerical producer/protocol before target outcomes. At this checkout the existing invocation is:

```sh
PYTHONPATH=src python scripts/run_maths_task_balance.py \
  --freeze-request /tmp/trinite-task-balance-request.json

# Use the exact request identity returned above.
PYTHONPATH=src python scripts/run_maths_task_balance.py \
  --request /tmp/trinite-task-balance-request.json \
  --request-identity sha256:EXPERIMENT \
  --verification-request /tmp/trinite-task-balance-verification.json \
  --output /tmp/trinite-task-balance-run --tier replay
```

These are instructions, not commands run in this review. Preserve both external request identities, all four expected cells and the fresh replay summary. Current sources/environment require a current request; do not reuse an older fingerprint. The acceptance condition remains at least 90% complete answer plus EOS in every arithmetic and maths task in both candidate seeds. Scoring stays training-only.

## A concrete smaller-core experiment

If a separate refinement experiment is warranted, compare the full task-balanced recipe with a smaller, fixed, task-balanced core using the same admitted mathematical facts. This tests your hypothesis directly without a context or architecture change.

| Setting | Full control | Refined candidate |
| --- | --- | --- |
| Maths semantic facts | All 999 training facts | Target 32 per task, 384 total |
| Maths carrier rows | All 1,998 | Both carriers per selected fact, 768 total |
| Arithmetic rows | All 264 | All 264 |
| Unique joint rows | 2,262 | Target 1,032 |
| Context / architecture | 64 / existing dense model | Identical |
| Visits per update | Four arithmetic, four maths | Identical |
| Task sequence | Existing round-robin tasks | Identical |
| Updates / seeds | 8,192 / 0,1 | Identical |
| Final diagnostic denominator | All original unique training rows | Identical, including omitted core rows |

The candidate improves repetitions of selected facts while retaining task coverage. It does not further compress examples that already fit. It is a curriculum recipe comparison: row selection, distribution and repeated exposure change together. It is not compute-matched superiority or a clean causal estimate of dataset size alone.

### Deterministic selection

Make the core selector a pure function of the admitted **training** rows, a frozen selection version and a predeclared selection seed. It must never consult predictions, losses, validation/test labels or a preferred model's successes.

1. Group carrier rows by task and semantic identity. Retain the parent's family IDs and split labels; do not resplit or move facts.
2. Require at least one selected semantic fact from every training family represented in each task. Preserve all twelve tasks.
3. Require coverage of applicable formal/answer categories: zero, positive and negative results; zero operands and signed operands; boundary/invalid binomial cases; modular wrap and no wrap; singular and unique systems; integer and rational unique solutions. Derive requirements exclusively from categories that actually occur in the training pack.
4. Select anchors with deterministic category coverage and hash tie-breaking, then fill each task to 32 semantic facts by frozen hash rank. Include both original carriers for every selected fact.
5. Fail admission if required coverage cannot fit the predeclared cap. Any different cap or selector is a new protocol before outcomes. Retain excluded-training identities and counts in the selection manifest.

Do not oversample only majority answers, remove difficult cases because they perform poorly, or pick convenient families after evaluating a model. Keeping both carriers avoids confounding this first comparison with carrier removal. A single-carrier experiment can be separate if carrier interference later becomes the explicit question.

### Evaluation and interpretation

Use all 264 arithmetic and 1,998 maths training rows as the final unique diagnostic view, with a separate selected/omitted breakdown. Repeated visits must not increase accuracy denominators. A candidate that reaches 90% only on its selected core has shown core memorization, not success on the original workload.

Report every task, family and carrier; singular/unique and rational solve counts; majority baselines; malformed/missing-EOS outputs; actual input/target tokens; per-row/task visits; numerical wall time and peak memory. Retain both seeds and all regressions. The original per-task acceptance requirements should remain the main gate. Never select the best seed or early checkpoint after seeing scores.

Identical context/shapes allow the unchanged native initializer to provide paired initial tensors. Record and compare initialization identities. The selector seed is distinct from the model seed and cannot be searched against test outcomes. Different answer lengths mean matching updates and row visits does not automatically match scored tokens; retain that difference explicitly.

## Diagnose fold-sum separately

The current scalar-sum failure is a useful focused target. Before mixing more tasks or changing context, compare a sum-only view with the existing count/sum/squares view using the same 1,150 admitted sum rows, model and fixed native optimizer. Keep every original family and both carriers. No numerical test/validation rows enter updates or diagnostics.

Choose the interpretation before execution. At equal updates, sum-only gets approximately three times as many sum visits; that comparison couples isolation with exposure. A later exposure-controlled comparison can instead use complete cycles: eight visits to every row gives 1,150 sum-only updates versus 3,450 mixed updates at batch eight. That matches sum-row visits but changes total updates, intervening tasks and compute. Neither design isolates all factors. Log both budgets and avoid describing either as pure proof of interference.

If sum-only cannot fit its full training view, consider a separately controlled model-capacity or supervision experiment. If it fits while the joint view fails, investigate exposure/task interference. If training fits but fresh families fail, address algorithm generalization and coverage rather than context.

Exact procedural traces are a possible later intervention: for values `[1,-2,2]`, deterministic running sums are `[1,-1,1]`. Generate and independently verify such traces from the same formal facts; disclose their extra supervised tokens and output length. Score the original final answer separately. This changes the learning/scoring protocol and may deliberately make sequences longer. Preserve the original compound fold and traversal gates; success on scalar components does not close them.

Formatting and intermediate supervision have improved arithmetic learning in other small transformers, which motivates testing this route. Their results do not guarantee Trinite's outcome. See [Lee et al., Teaching Arithmetic to Small Transformers](https://arxiv.org/abs/2307.03381).

## Code boundaries and evidence

Add the new helpers in a separate versioned namespace such as `src/trinite/retention_v2/refinement/`, with a small explicit selector, protocol/spec and experiment composition. Add a thin `scripts/run_maths_refinement.py` only when implementing that experiment. **These paths are proposals and do not exist in this review.**

Reuse:

- Existing maths/learning generators, independent oracles and actual parent admission audits.
- `training.py` for batching, masked loss, native AdamW and updates.
- The existing task scheduler for task-slot order.
- The authoritative prompt-only scorer, safe tensor reader, evidence verifier and optimizer replay operations.

The derived core needs its own scoped view schema and deterministic audit binding its parents, selector source/version, selected and excluded identities, coverage, and counts. Do not make the frozen maths admission accept arbitrary edited subsets. A new request must bind the complete runtime source closure, protocol, environment, parent/core manifests, schedule, unique diagnostic view, model and all expected artifacts. A thin archive adapter may be needed for the new schemas; retain independent commitments and fresh verification rather than caching an old success receipt.

Affected requirements: TRI-I02/I03 (native initialization and scoped data admission), I05/I07/I08 (CPU bounds, identities and replay), I11 (split/exposure isolation), I12 (one authoritative operation), and I13/I14 (negative evidence and versioned compatibility). Historical protocols, fixtures, producers and failed results remain byte-preserved. Geometry loss remains zero. This is a new experiment beside historical results, not a compatible replay of their checkpoints.

Meaningful implementation checks are exact subset regeneration, coverage failure cases, parent-family/carrier inheritance, exclusion of validation/test rows, prompt-to-answer uniqueness over the complete consumed stream, matched arithmetic/task-slot schedules, true target counts, bounded training and full optimizer replay, source/request mutation rejection, and unchanged-byte read-only verification.

### Namespace tasks before combining scalar workloads

The audit found 16 conflicting prompts if scalar arithmetic/fold/lattice packs are concatenated. For a new mixed scalar curriculum, use unique tags such as `FC`, `FS`, `FQ` for fold count/sum/squares, while preserving the original archived renderings. New renderings need their own exact parser checks, transformation lineage and source/admission identities. The existing separate-workload scalar runs do not need repair or resealing.

## Fresh generalization after training development

The visible historical test sets have already informed project development. Reusing their labels as a tuning target cannot produce a fresh confirmation. Freeze a genuinely new family-level evaluation protocol and independent exact labels before selected-model outcomes. New surface carriers or rehashing the same known families are insufficient.

Keep generation caps frozen from the grammar, compare against training-derived majority baselines, score every task and retain all failures. Separate any new extrapolation tasks from matched-distribution held-out tasks. For rational algebra, explicitly establish fresh rational-family coverage rather than relying on the sole known orbit currently forced into training. The fresh confirmation generator is separate later work; the proposed core experiment does not claim to supply it.

## When and how to expand context

Expand only when an admitted task needs a longer individual sequence. Reserve space for BOS, complete prompt, the task-wide maximum generated answer/trace and EOS. Reject overlength data at admission; never silently crop operands or targets.

For the current width-64 architecture:

| Configured context | Parameters | Position parameters | Attention cells at full length, batch 8 / heads 4 |
| --- | ---: | ---: | ---: |
| 64 | 86,528 | 4,096 | 131,072 |
| 128 | 90,624 | 8,192 | 524,288 |
| 256 | 98,816 | 16,384 | 2,097,152 |

Attention storage scales with the square of the **actual padded batch length**, not automatically the configured maximum. Since current batches are short, increasing the ceiling alone does not impose full-length attention cost. It does add positional/optimizer storage, and unused positions receive no task training signal. These cell counts are analytic, not measured runtime or whole-process memory estimates.

64→128/256 needs a new frozen training protocol/request and fresh model/optimizer state; the core bounds already permit it. Same seed is insufficient for exact shared-tensor pairing across contexts: `Decoder.__init__` initializes position embeddings before block weights, so a larger position table changes subsequent RNG draws. Any context ablation requiring matched shared tensors must explicitly version a paired native initialization procedure and verify those identities.

Above 256 requires changes to `ModelConfig`, `ByteTokenizer`, any parser/capture/checkpoint bounds that become relevant, and numerical/resource tests. For example, batch eight/four heads/context 512 allocates 8,388,608 attention cells, exceeding the current 4,194,304-cell guard. Reducing batch size or reviewing the resource budget is required. Learned absolute positions also need actual long-sequence training; changing a constant does not teach extrapolation.

For this repository, the refined curriculum experiment gives a more informative next comparison than a larger context window.
