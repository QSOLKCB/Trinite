# Full CPU and optional-lane validation

**All 227 required CPU/research tests passed.** The complete original-commit retest ran 468 tests: 467 passed, one separate connectome test errored, and none were skipped. A one-line test fix passes in an isolated worktree. The original exact-commit checkout and every tracked file remain byte-identical.

This follow-up uses an isolated CPython 3.12.13 environment and the repository's hash-locked dependencies. The original failure log and corrected test result are both retained; the original run is not relabelled as passing.

## Environment

| Setting | Value |
| --- | --- |
| Virtual environment | `/home/trent/dev/Trinite-venv-c9f4399` |
| Python | 3.12.13 |
| Torch | 2.8.0+cpu; CPU backend |
| Safetensors | 0.6.2 |
| NumPy | 2.3.5 |
| Transformers / tokenizers | 4.51.3 / 0.21.4 |
| PyArrow | 21.0.0; installed reader bytes attested by CNR's real verifier |
| Node | v24.19.0; separate checksum-verified runtime |
| CPU | AMD Ryzen 9 5950X 16-Core Processor |
| Torch CPU capability | AVX2 |
| Platform | Linux-7.0.0-38-generic-x86_64-with-glibc2.43 |
| Threads / determinism | One Torch thread; strict deterministic algorithms |

`uv` provisioned Python 3.12 and seeded a venv. Pip installed all three existing locks together with `--require-hashes --no-deps`: `requirements.lock`, `requirements.reference.lock`, and `requirements.connectome.lock`. `pip check` passed. The optional packages were installed to cover all independent test lanes, and the repository's strict native CPU environment validator also passed.

The donor suite requires exactly Node v24.19.0. That version was acquired separately from nodejs.org, verified against its official SHA-256 manifest, and selected through the test process's PATH. The existing Node/system Python installations were left separate. Downloads, runtimes and the venv are outside the checkout and are excluded from the report ZIP.

## Checks actually completed

| Suite | Tests | Process wall time | Result |
| --- | ---: | ---: | --- |
| Standard-library and embedded frozen geometry | 171 | 22.0 s | Passed; no skips |
| Frozen PROVENANCE upstream | 51 | 0.2 s | Passed; no skips |
| Complete required native CPU and research runner | 227 | 948.2 s | Passed; no skips |
| Optional reference backend | 4 | 2.6 s | Passed; no skips |
| Authentic connectome / retained CNR v3 replay | 1 | 1.6 s | One test error on original; isolated fix passes |
| Pinned ETQ donor runtime | 14 | 9.0 s | Passed; no skips |
| Original total | 468 | | 467 passed; one error; zero skips |
| Isolated corrected connectome rerun | 1 | 5.5 s | Passed; no skips |

Negative tests deliberately produce worker-failure and rejection messages in the research logs. Their expected outcomes were checked by the tests; the required CPU/research suite passed. The original connectome test's `UnboundLocalError` is a separate genuine test error, documented below.

The authoritative `scripts/check_research_cpu.py` ran every suite in its unchanged declared order: model, training, geometry, comparison, foundations, convergence, budget, learning, generalization, scalar, fold exposure, fold order, maths, maths retention, retention v2, retention budget and task balance. Standalone reference, real-connectome and donor suites were also executed. Frozen geometry upstream tests are already included by root discovery through the repository's pinned import adapter.

Additional checks passed: dependency consistency, strict CPU/environment and PyArrow reader attestation, exact donor-runtime verification, reference configuration validation, admitted formal-fixture audit, and dense/ternary model inspection with the declared detached capture. Pre/post inventories compared SHA-256 and byte count of every tracked file; the original checkout's git status remained clean.

## Connectome test defect and verified fix

At `tests/cnr/test_cnr001_full.py:30`, the test calls `json_bytes` before a redundant function-local import at line 41. Python therefore treats that name as local throughout the function and raises `UnboundLocalError`. The function never reaches its later retained-archive checks in the original run. This is a test scoping defect; the strict PyArrow reader attestation and preceding genuine graph analysis succeed.

The [proposed patch](torch-validation/cnr-json-bytes-scope-fix.patch) removes only the redundant inner import, leaving the existing module-level import in use. It changes one test line and preserves every assertion. I applied it exclusively in `/home/trent/dev/Trinite-cnr-test-fix-c9f4399`, a separate detached worktree at the same commit, then reran the complete real-data test with the same venv. It passed, including the retained v3 request/analysis/verification byte comparisons.

[The fix receipt](torch-validation/cnr-fix-validation.json) records the command, result, patch identity and sole changed file. All runtime, protocol, fixture and historical evidence bytes remain identical to the original; no admission guard or source fingerprint was weakened. The [original error log](torch-validation/cnr-real-data-tests.log) and [corrected log](torch-validation/cnr-fixed-tests.log) are both included. Only the affected test was rerun after the test-only fix; the unchanged passing suites were not repeated.

Affected assurance requirements: TRI-I07/I08/I13/I14. This corrects test execution without changing numerical or scientific compatibility. It is a reviewable local patch, not a modification of the original checkout or a published PR.

## What this adds to the review

The follow-up exercises real Torch forward passes, quantizer gradients, answer/EOS loss, native training, safetensors serialization/rejection, interrupted resume and bounded complete optimizer replay. Retention/task-balance assurance tests use real fresh training and upstream custody verification alongside unit tests for controller failures. The corrected CNR real-data test attests the installed PyArrow bytes, reads authentic Parquet inputs, and regenerates the retained v3 request/analysis/verification exactly. The reference backend uses small random models offline; no pretrained weights or model corpora were downloaded.

This closes the initial review's missing numerical-test coverage. It does not rerun the full historical learning matrices, reproduce their original host fingerprints, train the proposed smaller dataset, or measure a new learning improvement. Existing negative learning results and gates remain intact. The main recommendation is unchanged: current examples fit within context, and task balance/refinement is a more informative next experiment than context expansion.

This is one CPython 3.12 / CPU environment, not the complete hosted Python 3.11/3.12/3.13 matrix or independent replication of archived full research outcomes. Test success demonstrates scoped software conformance rather than model learning adequacy.

## Evidence and repeat commands

[Validation summary](torch-validation/validation-summary.json) records every command, exit status, duration, test count and limits. [Environment](torch-validation/environment.json) records the CPU/kernel/interpreter and all installed distributions. Each command has its full log under `torch-validation/`; [the before inventory](torch-validation/repository-inventory-before.json) binds the unchanged tracked bytes. [The runner](torch-validation/run_validation.py) shows the exact orchestration used.

To repeat into a new output directory with the retained venv and isolated Node runtime:

```sh
mkdir /tmp/trinite-full-retest
cp /home/trent/dev/Trinite-reports-c9f4399/torch-validation/run_validation.py \
  /tmp/trinite-full-retest/run_validation.py
/home/trent/dev/Trinite-venv-c9f4399/bin/python \
  /tmp/trinite-full-retest/run_validation.py
```

The runner sets one-thread/offline settings, selects the isolated Node executable, executes each required lane, and writes new logs/receipts beside its copied script. It does not install dependencies or modify historical evidence. A nonzero test, skipped test, missing suite result, changed tracked byte or dirty checkout makes its final status fail. The earlier CPython 3.14 standard-library logs remain in the packet as the initial review record; the follow-up logs are separately identified.
