#!/usr/bin/env python3
"""Run all repository test lanes in the isolated pinned environment."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

REPO = Path('/home/trent/dev/Trinite-review-c9f4399')
OUT = Path(__file__).resolve().parent
PYTHON = '/home/trent/dev/Trinite-venv-c9f4399/bin/python'
NODE_BIN = '/home/trent/dev/Trinite-test-tools/node-v24.19.0-linux-x64/bin'
COMMIT = 'c9f4399eca3bb380136321453ff2c6222f0bbaec'
env = dict(os.environ)
env.update(PYTHONPATH='src', PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0',
           OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false',
           PATH=str(Path(PYTHON).parent) + os.pathsep + NODE_BIN + os.pathsep + env['PATH'])


def now():
    return datetime.now(timezone.utc).isoformat()


def inventory():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).decode().split('\0')
    return {name: {'bytes': (REPO/name).stat().st_size,
                   'sha256': hashlib.sha256((REPO/name).read_bytes()).hexdigest()}
            for name in names if name}


def save():
    (OUT/'validation-summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n')


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert head == COMMIT, head
before = inventory()
(OUT/'repository-inventory-before.json').write_text(json.dumps(before, sort_keys=True, indent=2)+'\n')
summary = {'schema': 'trinite.full-test-review.v1', 'commit': head, 'started_at': now(),
           'python': PYTHON, 'node_bin': NODE_BIN, 'status': 'running', 'commands': [],
           'environment_settings': {k: env[k] for k in ('PYTHONHASHSEED', 'OMP_NUM_THREADS',
               'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE')},
           'limits': ['One CPython 3.12 environment; not the 3.11/3.12/3.13 CI matrix.',
                      'Bounded test training/replay only; no full historical model matrix replay or new learning experiment.']}

environment_code = '''import importlib.metadata, json, platform, sys, torch
from trinite.training import require_environment
from trinite.cnr001.core import attest_reader
torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)
record = require_environment()
record['executable'] = sys.executable
record['installed_distributions'] = dict(sorted((d.metadata['Name'], d.version) for d in importlib.metadata.distributions()))
record['pyarrow_reader_attestation'] = attest_reader()[0].__name__
print(json.dumps(record, indent=2, sort_keys=True))
'''

commands = [
    ('pip-check', [PYTHON, '-m', 'pip', 'check'], False, 60),
    ('environment', [PYTHON, '-c', environment_code], False, 120),
    ('node-version', ['node', '--version'], False, 30),
    ('stdlib-tests', [PYTHON, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], True, 600),
    ('upstream-tests', [PYTHON, '-m', 'unittest', 'discover', '-s', 'tests/upstream', '-v'], True, 120),
    ('research-cpu-tests', [PYTHON, 'scripts/check_research_cpu.py'], True, 3600),
    ('reference-tests', [PYTHON, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-v'], True, 600),
    ('cnr-real-data-tests', [PYTHON, '-m', 'unittest', 'discover', '-s', 'tests/cnr', '-v'], True, 600),
    ('etq-donor-check', [PYTHON, 'scripts/check_etq_donor.py'], False, 120),
    ('etq-donor-tests', [PYTHON, '-m', 'unittest', 'discover', '-s', 'tests/etq_upstream', '-v'], True, 300),
    ('validate-config', [PYTHON, '-m', 'trinite', 'validate-config', 'configs/reference.json'], False, 30),
    ('audit-fixture', [PYTHON, '-m', 'trinite', 'audit-fixture', 'fixtures/formal-v1'], False, 30),
    ('inspect-dense', [PYTHON, '-m', 'trinite', 'inspect-model', '--lane', 'dense', '--text', '1+1=2'], False, 120),
    ('inspect-ternary', [PYTHON, '-m', 'trinite', 'inspect-model', '--lane', 'ternary', '--text', '1+1=2',
                         '--capture-layer', 'final', '--capture-position', '0'], False, 120),
]
for name, argv, tests, timeout in commands:
    summary['current_command'] = name
    save()
    print(now(), 'START', name, flush=True)
    start = time.monotonic()
    record = {'name': name, 'argv': argv, 'log': name+'.log', 'started_at': now()}
    try:
        with (OUT/(name+'.log')).open('w') as log:
            proc = subprocess.Popen(argv, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT,
                                    start_new_session=True)
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                import signal
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise
        raw = (OUT/(name+'.log')).read_text()
        record.update(exit_code=rc, seconds=round(time.monotonic()-start, 3), status='passed' if rc == 0 else 'failed')
        if tests:
            matches = re.findall(r'Ran (\d+) tests? in ([0-9.]+)s', raw)
            record['test_count'] = int(matches[-1][0]) if matches else 0
            record['skipped'] = sum(int(v) for v in re.findall(r'skipped=(\d+)', raw))
            record['failures'] = sum(int(v) for v in re.findall(r'failures=(\d+)', raw))
            record['errors'] = sum(int(v) for v in re.findall(r'errors=(\d+)', raw))
            if not matches or record['skipped']:
                record['status'] = 'failed'
        if name == 'environment' and rc == 0:
            (OUT/'environment.json').write_text(json.dumps(json.loads(raw), indent=2, sort_keys=True)+'\n')
    except Exception as error:
        record.update(status='failed', error=repr(error), seconds=round(time.monotonic()-start, 3))
    summary['commands'].append(record)
    save()
    print(now(), record['status'].upper(), name, record.get('test_count', ''), 'seconds', record['seconds'], flush=True)

after = inventory()
summary['tracked_files_unchanged'] = before == after
summary['changed_tracked_files'] = [p for p in before if before[p] != after.get(p)]
summary['repository_status'] = subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True)
summary['completed_at'] = now()
summary['test_count'] = sum(c.get('test_count', 0) for c in summary['commands'])
summary['skipped'] = sum(c.get('skipped', 0) for c in summary['commands'])
summary['status'] = 'passed' if (all(c['status'] == 'passed' for c in summary['commands'])
    and summary['tracked_files_unchanged'] and not summary['repository_status']) else 'failed'
summary.pop('current_command', None)
save()
print(now(), 'COMPLETE', summary['status'], 'tests', summary['test_count'], flush=True)
sys.exit(0 if summary['status'] == 'passed' else 1)
