"""Verify the proposed one-line test fix in the separate worktree."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/trent/dev/Trinite-cnr-test-fix-c9f4399')
ORIGINAL = Path('/home/trent/dev/Trinite-review-c9f4399')
OUT = Path(__file__).resolve().parent
PYTHON = '/home/trent/dev/Trinite-venv-c9f4399/bin/python'
TEST = 'tests/cnr/test_cnr001_full.py'
baseline = json.loads((OUT/'repository-inventory-before.json').read_text())
changes = [p for p, expected in baseline.items()
           if hashlib.sha256((ROOT/p).read_bytes()).hexdigest() != expected['sha256']]
assert changes == [TEST], changes
old = (ORIGINAL/TEST).read_bytes()
new = (ROOT/TEST).read_bytes()
assert new == old.replace(b'        from trinite.contracts import json_bytes\n', b'')
env = dict(os.environ, PYTHONPATH='src', PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0',
           OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
argv = [PYTHON, '-m', 'unittest', 'discover', '-s', 'tests/cnr', '-v']
start = time.monotonic()
with (OUT/'cnr-fixed-tests.log').open('w') as log:
    result = subprocess.run(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
seconds = round(time.monotonic()-start, 3)
after_changes = [p for p, expected in baseline.items()
                if hashlib.sha256((ROOT/p).read_bytes()).hexdigest() != expected['sha256']]
assert after_changes == [TEST], after_changes
original_changes = [p for p, expected in baseline.items()
                    if hashlib.sha256((ORIGINAL/p).read_bytes()).hexdigest() != expected['sha256']]
assert not original_changes, original_changes
original_status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ORIGINAL, text=True)
assert not original_status
raw = (OUT/'cnr-fixed-tests.log').read_text()
receipt = {'schema':'trinite.cnr-test-fix-verification.v1',
           'base_commit':'c9f4399eca3bb380136321453ff2c6222f0bbaec',
           'worktree':str(ROOT),'argv':argv,'exit_code':result.returncode,'seconds':seconds,
           'test_count':1,'status':'passed' if result.returncode == 0 and raw.rstrip().endswith('OK') else 'failed',
           'only_modified_file':TEST,'original_checkout_unchanged':True,
           'patched_test_sha256':hashlib.sha256(new).hexdigest(),
           'patch_sha256':hashlib.sha256((OUT/'cnr-json-bytes-scope-fix.patch').read_bytes()).hexdigest(),
           'runtime_protocol_fixture_and_evidence_bytes_unchanged':True,
           'log':'cnr-fixed-tests.log'}
(OUT/'cnr-fix-validation.json').write_text(json.dumps(receipt, indent=2, sort_keys=True)+'\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)
