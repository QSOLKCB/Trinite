# Trinite dataset and context review

Reviewed on 2026-10-13 at exact commit `c9f4399eca3bb380136321453ff2c6222f0bbaec`.

Start with [the recommendation](01-recommendation.md), then read [the technical findings](02-technical-findings.md) and [the implementation plan](03-implementation-plan.md). The subsequent [full numerical validation](04-full-validation.md) records the completed Torch/safetensors retest.

The separate checkout is `/home/trent/dev/Trinite-review-c9f4399`. This packet contains reports, compact audit measurements, the audit script and verification logs. It contains no repository snapshot, dataset dump, model weights or historical evidence archives.

| File | Purpose |
| --- | --- |
| `01-recommendation.md` | Assessment of the hypothesis and recommended next step |
| `02-technical-findings.md` | Measured context use, data structure and historical outcomes |
| `03-implementation-plan.md` | Concrete refinement experiment, code boundaries and context alternative |
| `04-full-validation.md` | Completed full CPU and optional-lane retest |
| `torch-validation/` | New environment, command receipts, all test logs and reproducible runner |
| `dataset-audit.json` | Counts, lengths, splits, distributions, schedules and source fingerprints |
| `task-coverage.csv` | Task-level training coverage and answer novelty |
| `audit_dataset.py` | Reproduce the read-only analysis using the separate checkout |
| `audit-run.log` | Audit outcome |
| `stdlib-tests.log`, `upstream-tests.log` | Tests actually run in this review |
| `MANIFEST.json` | SHA-256 and byte count of every other packet member |

Reproduce the audit, with outputs in a new directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 audit_dataset.py \
  --repo /home/trent/dev/Trinite-review-c9f4399 \
  --output /tmp/trinite-dataset-review-reproduction
```

The audit verifies the commit, regenerates/audits ten existing corpora, checks exact tokenizer spans and target counts, and reconstructs the existing integer task scheduler. It makes no model call. It does not implement or train a refined dataset.

The initial review ran CPython 3.14.4: 171 standard-library repository tests and 51 frozen upstream tests passed. The requested follow-up created an isolated CPython 3.12.13 environment with Torch 2.8.0+cpu and safetensors 0.6.2. Of 468 original tests, 467 passed and one connectome test errored; none were skipped. All 227 required CPU/research tests passed. The connectome test passed after a one-line fix in a separate worktree; both logs and the proposed patch are retained. See `04-full-validation.md` for scope and receipts. Bounded native training and optimizer replay were tested; the full historical research matrices and proposed refinement were not rerun. The original checkout remains unchanged.
