# Recommendation

**Investigate dataset design first, but keep the research context at 64 tokens.** The specific explanation that the training data cannot fit in the context is unsupported by this checkout. The stronger version of your theory is that the task mix, exposure schedule and supervision make this small model's learning problem harder than necessary. That is plausible and testable; it is not established as the sole cause.

I cloned and checked out [your exact commit](https://github.com/QSOLKCB/Trinite/commit/c9f4399eca3bb380136321453ff2c6222f0bbaec). The checkout remains unchanged. The large source and evidence archives are separate from this report packet.

## What the model actually receives

The trainer receives `BOS + prompt + answer + EOS` for each example independently, with batch padding and answer/EOS loss masking. It does not receive the repository, a complete JSON dataset, provenance records, or all examples concatenated into one context. The context limits the active sequence; model parameters and optimization determine what can be learned across many sequences.

The fresh data audit found:

| Corpus | Training rows | Longest complete example, all splits | Context |
| --- | ---: | ---: | ---: |
| Arithmetic | 264 | 14 tokens | 64 |
| Compound folds | 1,150 | 24 tokens | 64 |
| Scalar folds | 3,450 | 19 tokens | 64 |
| Lattice | 210 | 17 tokens | 64 |
| Finite maths | 1,998 | 27 tokens | 64 |

These counts include BOS/EOS and use the actual byte tokenizer. All ten audited corpora fit their configured contexts. The historical ququart corpus reaches 34 tokens but also uses 64. Overlength inputs raise an error; truncation is not implemented. Even the frozen generation allowances fit.

## Why refinement is still worth testing

The current research model has 86,528 parameters; the larger 1.25M reference configuration is not the model used for these later learning results. Maths tasks contain 76–312 training rows each, so uniform sampling of rows creates unequal task exposure. Combining all maths rows with arithmetic also sharply reduces arithmetic exposure unless rehearsal is explicitly reserved. Both effects are visible in the existing code and research record.

The project has already tried simplifying compound outputs. Scalar fold preparation reduces the longest example from 24 to 19 tokens but triples the rows. At 4,096 updates and batch eight, average row exposure falls from about 28.5 to 9.5 visits. Fold-sum still misses its training gate, even though count and squares do much better. Therefore, shortening answers alone has not solved the problem. More repetition and a different order have also produced negative or mixed results.

High exposed training accuracy followed by poor held-out arithmetic/fold performance further shows that fitting examples is different from learning their rule. Reducing diversity can improve memorization while making this gap worse.

## What I would implement

1. Run the already implemented task-balanced maths comparison under a fresh request. At this commit it has conformance evidence but no published full research-matrix outcome. It tests a useful refinement without deleting examples or changing the model.
2. If joint learning still fails, compare that full task-balanced corpus with a deterministic smaller core drawn exclusively from the same admitted training facts. Keep both carriers, all task families and difficult categories; score every original unique training row, including omitted rows.
3. Separately isolate fold-sum to distinguish task interference from a failure to fit sum itself. Preserve the original composed-output gate. Any subsequent algorithm-teaching traces should come from exact procedural solvers and their independent checks.
4. Use a fresh family-level confirmation protocol after training development. Keep model width/depth as a later controlled diagnostic if the data changes fail.

The implementation plan gives a proposed 768-row maths core plus the unchanged 264 arithmetic rows, selector constraints, experiment controls and code boundaries. This is a proposed experiment, not an asserted improvement.

## Context expansion

Changing 64 to 128 or 256 is supported by the core configuration/tokenizer bounds, but the frozen scientific protocols still require a new version/request. It would add positional parameters without exposing any missing information in the existing examples. Longer context becomes useful if a future task actually needs longer operands, evidence, or exact intermediate states. Above 256, tokenizer/configuration guards and related numerical/resource contracts also need implementation changes.

The distinction between useful formatting and sheer data reduction is also supported by [Teaching Arithmetic to Small Transformers](https://arxiv.org/abs/2307.03381): its experiments show benefits from arithmetic-specific formatting and intermediate supervision. That is motivation for a controlled Trinite experiment, not evidence that the same recipe will work here.

**My advice: refine what is taught and how often it is taught; do not enlarge context to accommodate the total dataset.** The current inputs already fit, and neither dataset-only nor architecture-only explanations have been isolated experimentally.
