# Technical findings

Scope: exact commit `c9f4399eca3bb380136321453ff2c6222f0bbaec`, reviewed 2026-10-13. New measurements here concern data and deterministic scheduling. Historical neural results below come from retained repository records and were not numerically replayed during this review.

## Training and context

[ByteTokenizer.encode](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/src/trinite/tokenizer.py#L40) maps one UTF-8 byte to one token, inserts BOS/EOS, and rejects overlength examples. The vocabulary has 259 entries. Token counts therefore reflect bytes, not word tokens.

[The training batch and loss](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/src/trinite/training.py#L165) pad to the longest row in the current batch. They shift inputs/targets for next-token prediction, score answer bytes and EOS, and exclude prompt/PAD targets. [The maths state constructor](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/src/trinite/maths_learning.py#L60) extracts each row's `text`; it never tokenizes the surrounding JSON admission metadata. Different batch rows have separate attention sequences.

The architecture supports contexts up to 256 with learned absolute position embeddings. Later research uses two blocks, width 64, four heads, FF width 128, context 64 and 86,528 parameters. The reference file's six-block width-128 model has 1,247,232 parameters. Confusing these configurations can substantially overestimate the capacity behind reported outcomes.

Geometry loss is zero. Geometry observations consume detached captures; the CNR-001 MaleCNS/ETQ work added by this PR is a retrospective structural comparison. Its Parquet files do not enter native model training. See [CNR-001's scope](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/docs/CNR-001.md). The model's poor learning cannot be attributed to a nonzero geometry objective in these runs; this also does not prove its architecture is adequate.

## Fresh corpus audit

Ten corpora passed their existing admission audits, tokenizer checks, family isolation and contradiction checks. Median/max lengths cover all splits and include BOS/EOS. Scalar and learning wrappers overlap; these are not ten independent datasets all trained jointly.

| Corpus | Train / validation / test rows | Median / max tokens | Context |
| --- | --- | --- | ---: |
| Formal conformance fixture | 36 / 6 / 6 | 14 / 17 | 32 |
| Qutrit QEC | 96 / 32 / 32 | 17.5 / 22 | 64 |
| Ququart QEC | 180 / 60 / 60 | 24.5 / 34 | 64 |
| Learning arithmetic | 264 / 64 / 64 | 11 / 14 | 64 |
| Learning compound fold | 1,150 / 80 / 320 | 19 / 24 | 64 |
| Learning lattice | 210 / 20 / 40 | 15 / 17 | 64 |
| Scalar arithmetic | 264 / 64 / 64 | 11 / 14 | 64 |
| Scalar fold | 3,450 / 240 / 960 | 15 / 19 | 64 |
| Scalar lattice | 336 / 32 / 64 | 12 / 17 | 64 |
| Finite maths v2 | 1,998 / 502 / 654 | 21 / 27 | 64 |

Every corpus had zero family IDs crossing splits, zero contradictory prompts within that corpus, and zero exact-text duplicate rows. Every expected answer plus EOS fits its frozen generation cap. These checks support the existing finite data pipeline; they are not an independent legal assessment or neural-learning result. Complete measurements and hashes are in `dataset-audit.json`.

The finite-maths training texts total 37,983 encoded tokens across all 1,998 unique rows. That sum is cumulative corpus size, not a sequence the model must hold at once. It is also different from repeated input exposure or scored answer-token exposure.

## Exposure imbalance and interference

The [finite-maths generator](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/src/trinite/maths_data.py) contains twelve tasks:

| Task group | Rows per task | Approximate fraction of uniform maths row visits |
| --- | ---: | ---: |
| intersection-count, union-count | 76 | 3.8% each |
| choose | 84 | 4.2% |
| mod-add | 98 | 4.9% |
| determinant, dot, vector-add-0/1 | 104 | 5.2% each |
| matvec-0/1, solve-0/1 | 312 | 15.6% each |

The four largest tasks account for 1,248/1,998 rows, or 62.5%. Under the old pooled arithmetic-plus-maths recipe, arithmetic supplies only 264/2,262 rows, or 11.7%. Reserved four-arithmetic/four-maths rehearsal later changes that allocation explicitly.

I reconstructed the existing 8,192-update scheduler from current admitted row identities. It schedules 32,768 arithmetic visits and 32,768 maths visits per arm. Uniform maths selection gives roughly 1,242 visits to intersection-count and about 5,100 to each large task. The task-balanced candidate gives 2,730 or 2,731 visits per task. These are schedule calculations, not new training results.

Balancing task visits does not balance per-row exposure: a 76-row task gets about 36 visits per row, versus about nine for a 312-row task. The seed-0 full matrix cell has 167,979 scored targets under uniform selection and 162,194 under task balancing. The arms match updates and total row visits, not target tokens or compute. Reports should preserve that distinction.

The [task-balanced scheduler](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/src/trinite/retention_v2/task_balance/schedule.py) already exists. [Its contract](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/docs/MATHS-TASK-BALANCE.md) records implementation/conformance and leaves the full research outcome pending at this commit.

## Refinement has already been partly tested

The scalar transformation maps each compound fold into count, sum and squares. It preserves the parent's family/split and independently checks labels. Each task has 1,150 training rows, so the new corpus has 3,450 rows. With 32,768 row visits, average visits per row fall from 28.49 for compound folds to 9.50 for scalar folds. This is an exposure change alongside shorter outputs, not a pure test of answer complexity.

Recorded evidence:

| Experiment | Recorded finding | Implication |
| --- | --- | --- |
| [Matched learning](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/docs/LEARNING.md) | Dense arithmetic/lattice fit their training rows; dense fold clears its floor. Held-out arithmetic is 0/64, 1/64, 1/64; fold is 37/320, 0/320, 0/320. | Training fit alone does not establish rule learning. |
| [Scalar learning](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/docs/SCALAR-LEARNING.md) | Dense fold sum is 934, 868, 882 / 1,150, below the 1,035 threshold in every seed. Count/squares do substantially better. Held-out scoring is blocked. | Shorter scalar targets help some components but do not solve sum. |
| [Fold exposure](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/docs/FOLD-EXPOSURE.md) | Consecutive 2×/4× sum schedules reduce sum accuracy in every seed. | Blind repetition is not an evidenced solution. |
| [Fold order](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/docs/FOLD-ORDER.md) | Equal eight visits per example; mixed order helps sum in one seed and harms it in two. All cells fail sum. | Ordering alone has no consistent demonstrated benefit. |
| [Retention budget](https://github.com/QSOLKCB/Trinite/blob/c9f4399eca3bb380136321453ff2c6222f0bbaec/docs/MATHS-RETENTION-BUDGET.md) | 8,192 updates improve maths totals to 1,206 and 1,269 / 1,998; every maths task still fails its 90% gate. Arithmetic retention passes. | More exposure helps aggregate fit but does not close joint learning. |

I inspected these published records and their source relationships. I did not reverify their archived neural checkpoints or reproduce their optimizer trajectories.

## Coverage limits

The arithmetic corpus has only eight training families, compound/scalar folds twelve, and maths twenty-two overall; individual algebra tasks have eight. Both carriers double rows without creating independent mathematical facts. A smaller core needs to preserve these limited families rather than further thinning them accidentally.

The current scalar-fold audit shows all 320 test squares rows have complete answers absent from squares training answers. Fold families depend on absolute-value multisets, making squares strongly tied to family identity. The retained diagnostic also reports that every held-out compound fold answer tuple is absent from training. These are genuine challenges for memorization; they do not invalidate the task or prove the cause of failure.

Finite-maths v2 assigns the sole absolute-determinant-two orbit to training to provide rational answer vocabulary. No rational-answer generalization is demonstrated by this split. Linear-system `ERR`, zero answers and class imbalance require separate metrics; aggregate accuracy can conceal failures on unique systems.

## A concrete integration hazard

There are zero contradictory training prompts in the actual joint arithmetic-plus-maths corpus. However, a hypothetical concatenation of scalar arithmetic, fold and lattice training packs creates **16 conflicting prompts**. Arithmetic subtraction and scalar fold sum both use `S`. For example, `S:1,1=` means subtraction with answer `0` in one pack and sum with answer `2` in the other.

The current scalar experiments train workloads separately, so this is not an explanation for their historical failures. It is a defect to prevent in a future combined refined curriculum: namespace tasks before mixing and check prompt-to-answer uniqueness across the entire consumed stream.

## Confidence and remaining uncertainty

Context overflow is ruled out for the audited inputs and current caps. Data correctness, family separation and the current joint prompt vocabulary passed the existing deterministic audits. Exposure imbalance and limited independent coverage are directly measurable. Task interference, capacity, representation and optimization remain competing explanations. Only controlled neural experiments can separate them.
