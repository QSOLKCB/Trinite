#!/usr/bin/env python3
"""Read-only data audit of the exact review checkout; no model or training call."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import platform
import statistics
import subprocess
import sys

COMMIT = 'c9f4399eca3bb380136321453ff2c6222f0bbaec'


def digest(raw):
    return 'sha256:' + hashlib.sha256(raw).hexdigest()


def distribution(values):
    values = sorted(values)
    return {'min': values[0], 'median': statistics.median(values),
            'p95_nearest_rank': values[math.ceil(.95 * len(values)) - 1],
            'max': values[-1], 'total': sum(values)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    if head != COMMIT:
        raise SystemExit('Wrong review commit: ' + head)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(repo / 'src'))
    from trinite import data, comparison_data, learning_data, curriculum_data, maths_data
    from trinite.contracts import ModelConfig, json_bytes, identity
    from trinite.tokenizer import ByteTokenizer
    from trinite.retention_v2.task_balance.schedule import schedule_rows, task_visits

    formal_raw = (repo / 'fixtures/formal-v1/dataset.json').read_bytes()
    formal_manifest = (repo / 'fixtures/formal-v1/manifest.json').read_bytes()
    packs = [('formal-v1', formal_raw, formal_manifest, data.audit_bytes, 32)]
    for kind in ('qutrit', 'ququart'):
        raw, manifest = comparison_data.dataset(kind)
        packs.append(('qec-' + kind, raw, manifest, comparison_data.audit_bytes, 64))
    for module, prefix in ((learning_data, 'learning'), (curriculum_data, 'scalar')):
        for kind in ('arithmetic', 'fold', 'lattice'):
            raw, manifest = module.dataset(kind)
            packs.append((prefix + '-' + kind, raw, manifest, module.audit_bytes, 64))
    raw, manifest = maths_data.dataset()
    packs.append(('maths-v2', raw, manifest, maths_data.audit_bytes, 64))

    result = {'schema': 'trinite.read-only-dataset-review.v1', 'commit': head,
              'environment': {'python': platform.python_version(), 'platform': platform.platform()},
              'limits': ['No neural training, numerical checkpoint verification, or optimizer replay.',
                         'Known validation/test data are descriptive only; no recipe was selected from their labels.'],
              'corpora': {}, 'source_files': {}}
    examples_by_pack = {}
    task_rows = []
    for name, raw, manifest_raw, audit, context in packs:
        admitted = audit(raw, manifest_raw)
        rows = json.loads(raw)['examples']
        examples_by_pack[name] = rows
        tokenizer = ByteTokenizer(context)
        family_splits = defaultdict(set)
        prompts = defaultdict(set)
        for row in rows:
            encoding = tokenizer.encode(row['text'], answer_start=len(row['prompt'].encode()))
            assert len(encoding.input_ids) == len(row['text'].encode()) + 2
            assert sum(encoding.loss_mask) == len(row['answer'].encode()) + 1
            assert row['text'] == row['prompt'] + row['answer']
            family_splits[row['family_id']].add(row['split'])
            prompts[row['prompt']].add(row['answer'])
        split_families = sum(len(v) > 1 for v in family_splits.values())
        contradictions = sum(len(v) > 1 for v in prompts.values())
        assert split_families == contradictions == 0
        record = {'dataset_identity': digest(raw), 'manifest_identity': digest(manifest_raw),
                  'dataset_file_bytes': len(raw), 'manifest_file_bytes': len(manifest_raw),
                  'admission_regeneration_passed': True, 'configured_context': context,
                  'families_crossing_splits': split_families, 'contradictory_prompts': contradictions,
                  'exact_text_duplicate_rows': len(rows) - len({r['text'] for r in rows}),
                  'splits': {}, 'tasks': {},
                  'encoded_example_tokens': distribution([len(r['text'].encode()) + 2 for r in rows]),
                  'overlength_example_counts': {str(c): sum(len(r['text'].encode()) + 2 > c for r in rows)
                                               for c in (32, 64, 128, 256)},
                  'longest_examples': [{'prompt': r['prompt'], 'answer': r['answer'], 'split': r['split'],
                                        'tokens': len(r['text'].encode()) + 2}
                                       for r in sorted(rows, key=lambda r: len(r['text'].encode()), reverse=True)[:2]]}
        generation_caps = {'formal-v1': 2, 'qec-qutrit': 5, 'qec-ququart': 6,
                           'learning-arithmetic': 5, 'learning-fold': 9, 'learning-lattice': 9,
                           'scalar-arithmetic': 5, 'scalar-fold': 4, 'scalar-lattice': 9, 'maths-v2': 8}
        cap = generation_caps[name]
        record['frozen_generation_cap'] = cap
        record['max_bos_prompt_plus_generation_cap'] = max(len(r['prompt'].encode()) + 1 + cap for r in rows)
        assert all(len(r['answer'].encode()) + 1 <= cap for r in rows)
        assert record['max_bos_prompt_plus_generation_cap'] <= context
        for split in ('train', 'validation', 'test'):
            selected = [r for r in rows if r['split'] == split]
            record['splits'][split] = {'rows': len(selected),
                'families': len({r['family_id'] for r in selected}),
                'semantic_identities': len({r['semantic_identity'] for r in selected}),
                'encoded_example_tokens': distribution([len(r['text'].encode()) + 2 for r in selected]),
                'prompt_tokens_including_bos': distribution([len(r['prompt'].encode()) + 1 for r in selected]),
                'scored_answer_eos_tokens': distribution([len(r['answer'].encode()) + 1 for r in selected])}
        for task in sorted({r.get('task', 'mod-add') for r in rows}):
            group = [r for r in rows if r.get('task', 'mod-add') == task]
            train = [r for r in group if r['split'] == 'train']
            counts = Counter(r['answer'] for r in train)
            majority = sorted(counts, key=lambda a: (-counts[a], a))[0]
            train_answers = set(counts)
            entry = {'train_rows': len(train), 'train_families': len({r['family_id'] for r in train}),
                     'train_semantic_identities': len({r['semantic_identity'] for r in train}),
                     'train_answer_histogram': dict(sorted(counts.items())), 'train_majority_answer': majority,
                     'train_majority_correct': counts[majority], 'novel_answer_rows': {},
                     'encoded_example_tokens': distribution([len(r['text'].encode()) + 2 for r in group])}
            for split in ('validation', 'test'):
                entry['novel_answer_rows'][split] = sum(r['answer'] not in train_answers for r in group if r['split'] == split)
            record['tasks'][task] = entry
            task_rows.append({'corpus': name, 'task': task, 'train_rows': len(train),
                              'train_families': entry['train_families'],
                              'train_semantic_identities': entry['train_semantic_identities'],
                              'max_tokens_all_splits': entry['encoded_example_tokens']['max'],
                              'majority_answer': majority, 'majority_correct': counts[majority],
                              'test_novel_answer_rows': entry['novel_answer_rows']['test']})
        assert record['overlength_example_counts'][str(context)] == 0
        assert admitted['dataset_identity'] == digest(raw)
        result['corpora'][name] = record

    # Actual joint maths/legacy corpus: inspect all train prompts for ambiguity.
    def conflicts(pack_names):
        mapping = defaultdict(list)
        for name in pack_names:
            for row in examples_by_pack[name]:
                if row['split'] == 'train':
                    mapping[row['prompt']].append({'corpus': name, 'task': row.get('task'), 'answer': row['answer']})
        bad = {p: rs for p, rs in mapping.items() if len({r['answer'] for r in rs}) > 1}
        return {'conflicting_prompt_count': len(bad), 'examples': list(bad.items())[:5]}
    result['actual_joint_training_prompt_conflicts'] = conflicts(('learning-arithmetic', 'maths-v2'))
    result['hypothetical_scalar_joint_prompt_conflicts'] = conflicts(('scalar-arithmetic', 'scalar-fold', 'scalar-lattice'))

    # Reconstruct scheduling using the authoritative pure integer scheduler.
    legacy = [r for r in examples_by_pack['learning-arithmetic'] if r['split'] == 'train']
    maths = [r for r in examples_by_pack['maths-v2'] if r['split'] == 'train']
    result['scheduling_8192_updates'] = {}
    for seed in (0, 1):
        ranked = lambda rows: [{'identity': r['example_identity']} for r in sorted(rows,
                               key=lambda r: identity(json_bytes({'seed': seed, 'item': r['example_identity']})))]
        legacy_ranked, maths_ranked = ranked(legacy), ranked(maths)
        task_for = {r['example_identity']: r['task'] for r in maths}
        seed_result = {}
        for profile in ('control', 'candidate'):
            schedule = schedule_rows(legacy_ranked, maths_ranked, task_for, 8192, profile)
            visits = Counter(r['identity'] for r in schedule)
            groups = defaultdict(int)
            for row in maths:
                groups[row['task']] += visits[row['example_identity']]
            if profile == 'candidate':
                assert dict(groups) == task_visits(8192)
            lookup = {r['example_identity']: r for r in legacy + maths}
            seed_result[profile] = {'arithmetic_visits': sum(visits[r['example_identity']] for r in legacy),
                'maths_visits': sum(groups.values()), 'maths_task_visits': dict(sorted(groups.items())),
                'scored_targets': sum(n * (len(lookup[i]['answer'].encode()) + 1) for i, n in visits.items()),
                'nonpadding_input_tokens': sum(n * (len(lookup[i]['text'].encode()) + 1) for i, n in visits.items()),
                'maths_per_row_visits': {task: distribution([visits[r['example_identity']] for r in maths if r['task'] == task])
                                       for task in sorted(groups)}}
        result['scheduling_8192_updates'][str(seed)] = seed_result

    models = {}
    for context in (32, 64, 128, 256):
        config = ModelConfig(blocks=2, width=64, heads=4, feed_forward_width=128, context_length=context)
        models[str(context)] = {'parameters': config.parameter_count,
                               'position_parameters': context * 64,
                               'attention_cells_at_full_context_batch8_heads4': 8 * 4 * context * context}
    result['same_architecture_context_comparison'] = models
    for path in sorted((repo / 'src').rglob('*.py')):
        result['source_files'][str(path.relative_to(repo))] = digest(path.read_bytes())
    result['reviewed_evidence_files'] = {str(p.relative_to(repo)): digest(p.read_bytes())
        for p in sorted((repo / 'docs').glob('*.md'))}
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'dataset-audit.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    with (args.output / 'task-coverage.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(task_rows[0]))
        writer.writeheader(); writer.writerows(task_rows)
    print(json.dumps({'commit': head, 'corpora_audited': len(packs),
                      'all_admission_and_context_checks_passed': True,
                      'rows_by_corpus': {n: {s: v['rows'] for s, v in r['splits'].items()}
                                         for n, r in result['corpora'].items()},
                      'max_tokens': {n: r['encoded_example_tokens']['max'] for n, r in result['corpora'].items()},
                      'actual_joint_conflicts': result['actual_joint_training_prompt_conflicts'],
                      'hypothetical_scalar_joint_conflicts': result['hypothetical_scalar_joint_prompt_conflicts']}, indent=2))


if __name__ == '__main__':
    main()
