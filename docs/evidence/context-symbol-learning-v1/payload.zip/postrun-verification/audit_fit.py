"""Post-run read-only fit-checkpoint audit; never resumes the failed lifecycle."""
import argparse
import os
from pathlib import Path
import resource
import sys

p=argparse.ArgumentParser(description=__doc__)
for name in ('producer-root','frozen','freeze-sha','anchors','anchors-sha','run','run-anchor','run-sha'):
    p.add_argument('--'+name,required=True)
a=p.parse_args()
resource.setrlimit(resource.RLIMIT_AS,(4<<30,4<<30))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ[name]='1'
producer=Path(a.producer_root)
sys.path[:0]=[str(producer/'src'),str(producer/'scripts')]
import queue_evaluation_v1 as gate
from queue_learning_v1.artifacts import anchored_json,inventory,read_json
from trinite.contracts import json_bytes
from context_symbol_learning_v1 import custody,numerical,workers

run=Path(a.run)
before=inventory(run)
anchor=anchored_json(Path(a.run_anchor),a.run_sha)
gate.require(anchor==dict(schema='trinite.context-symbol-evidence-anchor.v1',freeze_sha256=a.freeze_sha,files=before),
    'external run inventory mismatch')
manifest,content=custody.context(Path(a.frozen),a.freeze_sha,Path(a.anchors),a.anchors_sha,live=False)
record=read_json(run/'run.json')
gate.require(record['stopped'] is not None and record['barrier_sha256'] is None and not record['scoring_started'],
    'this audit must preserve the stopped, unscored lifecycle')
info=read_json(run/'fit-17/training.json')
state=workers.load_checkpoint(run/'fit-17',info,content['train'],17,a.freeze_sha,True)
from trinite.training import model_identity,require_environment
identity=model_identity(state.model)
report=numerical.require_fit(state,content['train'])
gate.require(report==read_json(run/'fit-17/final.json')['fit_report'],'stored and regenerated fit reports differ')
gate.require(model_identity(state.model)==identity and inventory(run)==before,'read-only audit mutated evidence/model')
result=dict(schema='trinite.context-symbol-postrun-fit-audit.v1',producer_sha=manifest['producer_sha'],
    freeze_sha256=a.freeze_sha,run_anchor_sha256=a.run_sha,checkpoint_sha256=info['checkpoint_sha256'],
    step=state.step,target_tokens=state.target_tokens,parameters=sum(t.numel() for t in state.model.parameters()),
    exact=sum(r['exact'] for r in report),planned=len(report),report=report,model_identity=identity,
    environment=require_environment(),optimizer_updates_in_this_audit=0,run_bytes_unchanged=True,
    replaces_failed_mandatory_gate=False,authorizes_main_runs=False,optimizer_replay=False,
    scope='post-run configured native safe-load and training-only answer/EOS inference; mandatory subprocess gate remains failed')
print(json_bytes(result).decode('ascii'),end='')
