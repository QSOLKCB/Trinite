# Context-symbol learning v1 — fresh approval request

**PREPARATION COMPLETE; TRAINING NOT AUTHORIZED.** This is a request, not an owner approval declaration. No `owner-approval.json`, run directory or execution claim has been created. The consumed historical approval is not reused; this is not a resume. One fresh feasibility/freeze was performed, with no retry.

## Exact identities to approve

- Repository: QSOLKCB/Trinite.
- Producer SHA: `578d4793a02585a0bf8b86660c4fd99720db118c`.
- Producer tree: `215637e915c30e8fa54374f389e15be3f3a367e9` (identical to reviewed PR #123 tree).
- Freeze SHA-256: `f6cb7b0e254291bfdf7c2539ab9db5a3bd54ef5ae0fe696d125a132e9b2ee069`.
- Preparation-anchor SHA-256: `a1224ca2dcce2695ba6b1f89a1c1a5808db332289533bd1d0336d9e1b42fd1ef`.
- Supervised-feasibility SHA-256: `2f69ae751225393b3d998c125e960a6eadc67b19b98dca3eac3d037e70e6f9f0`.
- Source archive SHA-256: `df817cadfc41efb7aa538cde8897f5327065645c4638321005353aaa5605e6ac`; complete closure: 215 files.
- Data inventory SHA-256: `21b0311fc629bd95f52a01c0e57c756383599ea4b286a4d01b8c58d799c130d5`.
- Oracle executable SHA-256: `d0c61615163522c0cca9b3241e650e2d06ee12d7f59ae7bf1ab9152ac72ff269`.
- Dependency-lock SHA-256: `79d4e23cb96308a23f0855deb8e38a22744d1a4efe5a2fba5c2c9a91a246d5af`.

## Custody locations

- Clean detached producer: `/workspace/scratch/db1d34633ee0/context-symbol-preparation-578d4793-20261101T220403Z/producer`
- Frozen bundle: `/workspace/scratch/db1d34633ee0/context-symbol-preparation-578d4793-20261101T220403Z/frozen`
- Independent preparation anchor: `/workspace/scratch/db1d34633ee0/context-symbol-preparation-578d4793-20261101T220403Z/preparation.json`
- Supervised feasibility: `/workspace/scratch/db1d34633ee0/context-symbol-preparation-578d4793-20261101T220403Z/feasibility/supervised-feasibility.json`
- Full approval request: `/workspace/scratch/db1d34633ee0/context-symbol-preparation-578d4793-20261101T220403Z/APPROVAL-REQUEST.md`
- Checks and command receipts: `/workspace/scratch/db1d34633ee0/context-symbol-preparation-578d4793-20261101T220403Z/checks`

PR #123 was merged by the owner on 2026-11-01 at 21:59:37 UTC. The exact actual main-push SHA above has **79/79 workflows completed successfully**, checked at 22:08:55 UTC, not inferred from PR-head CI. `checks/ci-green.json` retains all run identities. Main is unprotected with no configured required-check contexts and no rulesets; every triggered main-push workflow was nevertheless required green here. Two path-filtered workflows (historical QEC control audit and final-forward export) did not trigger because their paths were untouched. No CI was manually rerun. The source checkout is clean and matches origin/main.

## Unchanged bounded schedule requested

| Stage | Initialization | Updates | Visits | Target tokens including EOS | Gate |
| --- | --- | ---: | ---: | ---: | --- |
| Fit | Fresh native seed 17 | 128 exactly, once | 1,024 on 8 unique train rows | 2,432 | Final step 128 must regenerate all 8/8 canonical answers plus EOS, including independent final-checkpoint reload |
| Main 17 | Independently fresh native seed 17; never fit weights/optimizer | 256 exactly, once | 2,048 on 360 unique train rows | 4,900 | Only after fit lifecycle gate succeeds |
| Main 29 | Independently fresh native seed 29; never fit weights/optimizer | 256 exactly, once | 2,048 on 360 unique train rows | 4,900 | Only after preceding stages succeed |
| Maximum | Three fixed attempts | 640 | 5,120 | 12,232 | First failure stops dependent stages; preserve every partial/failure |

Existing dense native decoder: 24,768 unique parameters, vocabulary259, context256, one block, width32, four heads, FF64, tied embedding/output. CPU float32 eager deterministic; geometry loss0. AdamW LR0.001, betas0.9/0.999, epsilon1e-8, weight decay0.01, clipping norm1; single tensor, foreach/fused/AMSGrad/capturable/maximize/differentiable disabled. Batch8; fixed SHA-256 train-ID ranking, cycle without shuffle. Answer bytes and EOS only receive native shifted loss. Final checkpoints only; training-only diagnostics; validation is reporting-only after commitments.

Unrestricted greedy generation, maximum three emitted tokens, EOS mandatory; accept exactly -1/0/1 plus EOS. No constrained decoding, stripping, repair or fallback. Fixed training-majority and context-ignoring baselines; every heldout prediction for both seeds and fixed baselines must be committed before privileged evaluation.

Limits: **120 seconds cumulative native updates per attempt; 900 seconds entire attempt; 2,700 seconds overall study** including preparation within execution, baselines, checkpoint restore, inference, commitments and scoring. **1 GiB per-process RSS; 2 GiB sampled aggregate process-tree RSS; 4 GiB hard per-process address-space; core dumps disabled.** No retries, resume, extra seeds, hyperparameter search, GPU, paid compute or budget expansion. A failure consumes its freeze authorization; a new output path does not authorize another attempt.

## Current-host feasibility and verification

- CPython3.12.14, Torch2.8.0+cpu and exact locked package versions; pip check passes. Runtime hashes bind interpreter, Torch extension/libtorch_cpu/libc10 and safetensors. Rust1.90.0 offline locked release build.
- Linux6.18.57 x86_64/glibc2.41, AMD EPYC9V74, AVX512; one Torch compute thread, recorded interop threads9. No backend substitution or environment change.
- Exactly **zero optimizer updates**, three synthetic worst-context backward/clip measurements; unchanged model identity `sha256:c9bcf73696146a60e266e4001bc065c298dccdc955ed75d2cba64f1d4db846e1`.
- Kernel seconds: 0.065276, 0.042017, 0.032209. Fourfold update projection: **66.843s <120s**. Full fourfold projection with admission/setup/diagnostic IO: **98.486s <900s**.
- Supervised feasibility wall time: 9.331s. Observed maximum process RSS: 680239104 bytes; aggregate RSS: 696492032 bytes. Supervisor exit0, no failure, observed updates0/target tokens0.
- Feasibility and freeze each independently observed648 public rows and evaluated360 training rows only. Read-only call-log audit confirms **zero heldout privileged calls**. No heldout target/scoring invocation and no scientific fit/main execution.
- Native admission and independent finite-world training checks; nine families, eighteen semantic table orbits; 360/144/144 train/validation/test rows, five/two/two whole families; zero historical/development orbit overlap;98 maximum complete tokens; no truncation.
- Existing custody.context read-only check passed: source ZIP, exact freeze inventory, source/runtime/executable bindings, data/splits/rights, training rows, schedule, feasibility and clean main. Frozen bytes unchanged.
- All33 files in prior `review-pr122-evidence` remain byte-identical. Historical producer/evidence/fixtures have not been modified. No GitHub write was made.

## Rights, exposure and limits

Data are original commissioned finite numeric tables/masks and minimal notation; software licensing is separate. No corpus, book text/OCR/images, teacher output or private chat enters the input. Admission's reviewed_on `2026-11-02` is the existing source-bound declaration, not a newly invented review timestamp; this preparation's CI observation occurred on2026-11-01 UTC. Preserve that source value without silently changing the producer.

The public scientific-family construction excludes all previously development-exposed table orbits. The previous stopped study used this same inventory and reached128 fit updates/8-of-8, then failed the independent validation-runtime guard; main seeds and heldout scoring remained unrun. This new preparation is not a new unseen dataset or independent confirmation of the old fit. No tuning, redrawing or schedule changes were made. Public construction and operator custody do not prove blindness. Fixed-size family transfer cannot establish unseen algorithms, sizes, domains or psychological truth.

Feasibility is a zero-update engineering projection, **not measured AdamW throughput, guaranteed completion, a learning result, optimizer replay or hardware attestation**. Sampled RSS cannot rule out transient peaks; host libraries/kernel/compiler and operator honesty remain trust boundaries. No Phase5, scaling, geometry, release or deployment gate advances.

## Requested owner decision

Approve or decline **one** execution using the full producer SHA and freeze SHA above and the exact bounded schedule. The requested authorization wording is:

> execute context-symbol-learning-v1 fit seed 17 once at step 128; only after final 8/8, main seeds 17 and 29 once at step 256

Only after explicit approval may a canonical owner declaration be created with approved_by Trent Slade, the exact producer/freeze identities, reviewed_merged_green true, optimizer_updates_ceiling640 and supervised_token_ceiling12232. This document does not make that declaration. Execution must recheck unchanged clean producer/runtime and fresh run/anchor destinations; any mismatch stops for a new decision.
